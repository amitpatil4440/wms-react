import React, { Component } from 'react'
import Header from '../Components/Header';
import axios from 'axios';
import { Link } from 'react-router-dom';
import '../Staff/GetDetails.css';

export default class GetDetails extends Component {
    constructor(props) {
        super(props)

        this.state = {
            email:'',
            Details: []
            
        }
        //this.DisplayAllDetails=this.DisplayAllDetails.bind(this);
       
    }
    DisplayAllDetails(){
        console.log('hello')
        let email = this.state.email;
        let url = "http://localhost:53678/api/Staff/GetDetailsByEmail?email=" + email ;
        axios.get(url).then(resp => {
            // alert(resp.data);
            this.setState({ Details: resp.data });
        }).catch(error => {
            console.warn(error);
        })

    }

    componentDidMount() {
        this.DisplayAllDetails();
    }
    // handleChange=(object)=> {
    //     this.setState(object);
    //    }


  render() {
    const {Details} = this.state;
    return (
        <>
      <Header></Header>
                <div>
                    <h2>Get Details</h2>
                    <div class="table-wrapper">
                        <table class="fl-table">
                            <thead>
                                <tr>
                                <th>Staff Id</th>
                                <th>Staff Name</th>
                                <th>Email</th>
                                <th>Availability Status</th>
                                <th>Working Status</th>
                                <th>Contact No</th>
                                <th>Gate No</th>
                                <th>PNR Number</th>
                                    


                                </tr>
                            </thead>
                            <tbody>
                                {
                                    Details.map(a =>
                                    
                                        <tr>
                                            
                                            <td>{a.staffId}</td>
                                            <td>{a.staffName}</td>
                                            <td>{a.email}</td>
                                            <td>{a.availability}</td>
                                            <td>{a.workingStatus}</td>
                                            <td>{a.contactNo}</td>
                                            <td>{a.gateNo}</td>
                                            <td>{a.pnrNo}</td>
                                        </tr>
                                )
                                    
                                }
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* <Link to={"/CheckByPNR"} class="hero-btn">Next Page</Link> */}

      </>
    )
  }
}

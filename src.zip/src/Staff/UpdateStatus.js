import React, { Component } from 'react'
import axios from 'axios'
import Header from '../Components/Header'
import WheelchairStatus from './WheelchairStatus'


export default class UpdateStatus extends Component {

    constructor(props) {

        super(props)


        this.state = {

            wId: '',
            status: ''

        }

        this.UpdateStatus = this.UpdateStatus.bind(this);

        this.handleChange = this.handleChange.bind(this);

    }

    UpdateStatus() {

        let wId = this.state.wId;

        let url = "http://localhost:53678/api/WheelChair/WheelChairUpdate?WId=" + wId;

        axios.put(url, {

            status: this.state.status

        }).then(response => {

            alert(response.data);
            window.location='/WheelchairStatus';

        }).catch(error => {

            alert(error);

        });

    }

    handleChange(object) {

        this.setState(object);

    }

    render() {
        
        return (
            <>
        <Header></Header>
            <div>
                UpdateStatus



                <table border={3} align="center">

                    <tr>

                        <td>

                            <label>Wheelchair Id</label>
                            <input type="text" name="wId" onChange={(e) => this.handleChange({ wId: e.target.value })}></input>

                        </td>

                    </tr>

                    <tr>

                        <td>

                            <label>Status</label>
                            <input type="text" name="status" onChange={(e) => this.handleChange({ status: e.target.value })}></input>

                        </td>

                    </tr>

                    <tr>

                        <td>


                            <button onClick={this.UpdateStatus} >Create</button>


                        </td>

                    </tr>
                </table>

            </div>
            </>
        )
        

    }

}





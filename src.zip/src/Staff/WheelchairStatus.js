import React, { Component } from 'react'
import axios from 'axios';
import '../Supervisor/ViewSSRRequests.css';
import Header from '../Components/Header'
import { Link } from 'react-router-dom';
export default class WheelchairStatus extends Component {
    constructor(props) {
        super(props)

        this.state = {
            Status: [],
            //    Check:[]
        }
        // this.SearchByPNR=this.SearchByPNR.bind(this);
        // this.handleChange=this.handleChange.bind(this);
    }
    DisplayWheelchairStatus() {
        let url = "http://localhost:53678/api/WheelChair/GetAllWheelChairs";
        axios.get(url).then(resp => {
            // alert(resp.data);
            this.setState({ Status: resp.data });
        }).catch(error => {
            console.warn(error);
        })

    }

    
    componentDidMount() {
        this.DisplayWheelchairStatus();
    }
   
    render() {
        const { Status } = this.state;
        return (
            <>
                <Header></Header>
                <div>
                    <h2>Wheelchair Status</h2>
                    <Link to={"/UpdateStatus"} onClick={this.create} className="btn btn-primary btn-block mb-3">Update</Link>
                    <div class="table-wrapper">
                        <table class="fl-table">
                            <thead>
                                <tr>
                                    <th>WheelChair Id</th>
                                    <th>Status</th>
                                    


                                </tr>
                            </thead>
                            <tbody>
                                {
                                    Status.map(a =>
                                        <tr>
                                            <td>{a.wId}</td>
                                            <td>{a.status}</td>
                                            
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* <Link to={"/CheckByPNR"} class="hero-btn">Next Page</Link> */}

            </>
        )
    }
}

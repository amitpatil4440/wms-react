import React, { Component } from 'react'
import { Link } from 'react-router-dom'

import './Header.css'

export default class Header extends Component {

 render() {

return (

 <>



<div class="header">

<a href="#default" class="logo">Wheelchair Request Management </a>

<div class="header-right">

{/* <a href="/Home">Home</a> */}


<Link to={"/Home"}>Home</Link>

<Link to={"/PassengerLogin"}>Passenger</Link>
<Link to={"/StaffLogin"}>Staff</Link>
<Link to={"/SupervisorLogin"}>Supervisor</Link>

<Link to={"/ContactUs"}>ContactUs</Link>
<Link to={"/AboutUs"}>AboutUs</Link>

{/* <a href="/ContactUs">ContactUs</a> */}

{/* <a href="/AboutUs">AboutUs</a> */}

</div>

</div>

 </>

 )

 }

}
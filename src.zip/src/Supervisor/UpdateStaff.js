import React, { Component } from 'react'
import './UpdateStaff.css'
import Header from '../Components/Header'
// import Footer from '../Components/Footer'
import axios from 'axios';
import { Link, useLoaderData, useParams, withRouter } from 'react-router-dom';
import { useState, useEffect, useRef } from 'react';

function UpdateStaff() {

  // const {email} = useParams();
  // const [staffId, setStaffId] = useState();
  // const [staffName, setStaffName] = useState();
  const [email, setEmail] = useState();
  const [availability, setAvailability] = useState();
  // const [workingStatus, setWorkingStatus] = useState();
  // const [contactNo, setContactNo] = useState();
  const [gateNo, setGateNo] = useState();
  const [pnrNo, setPnrNo] = useState();
  const [data, setData] = useState([]);


useEffect(() => {

      loadData();

 }, [])

  async function loadData() {

   const recievedData = await axios.get("http://localhost:53678/api/Staff/StaffStatusAvailable" )

  //  setData(recievedData.data[0]);
   setEmail(recievedData.data[0].email)
  //  setStaffId(recievedData.data[0].staffId)
  //  setStaffName(recievedData.data[0].staffName)
   setAvailability(recievedData.data[0].availability)
  //  setWorkingStatus(recievedData.data[0].workingStatus)
  //  setContactNo(recievedData.data[0].contactNo)
   setGateNo(recievedData.data[0].gateNo)
   setPnrNo(recievedData.data[0].pnrNo)
   

 }

 const handleChange = (e) => {
 setData({ ...data, [e.target.name]: e.target.value });

 };

 console.log(data);

 ///////////////////////////////////////

 const baseURL = "http://localhost:53678/api/Staff/StaffUpdate?Email=" ;

 const put_email = useRef(null);
//  const put_staffId = useRef(null);
//  const put_staffName = useRef(null);
 const put_availability = useRef(null);
//  const put_workingStatus = useRef(null);
//  const put_contactNo = useRef(null);
 const put_gateNo = useRef(null);
 const put_pnrNo = useRef(null);


 const [putResult, setPutResult] = useState(null);

 const fortmatResponse = (res) => {

 return JSON.stringify(res, null, 2);

 }


 function putData() {

 const id = put_email.current.value;

 if (id) {

  const putData = {

 email: put_email.current.value,
//  staffId: put_staffId.current.value,
//  staffName: put_staffName.current.value,
 availability: put_availability.current.value,
//  workingStatus: put_workingStatus.current.value,
//  contactNo: put_contactNo.current.value,
 gateNo: put_gateNo.current.value,
 pnrNo: put_pnrNo.current.value,

};

 alert("Staff Assigned Successfully...!")

 try {

 const res = fetch(`${baseURL}`, {

 method: "put",

 headers: {

 "Content-Type": "application/json"

 },
body: JSON.stringify(putData),

 });

 if (!res.ok) {

 const message = `An error has occured: ${res.status} - ${res.statusText}`;
 throw new Error(message);

 }

 const data = res.json();

 const result = {

 status: res.status + "-" + res.statusText,

 headers: { "Content-Type": res.headers.get("Content-Type") },

 data: data,

 };

 setPutResult(fortmatResponse(result));

 } catch (err) {

 setPutResult(err.message);

 }

 }
 }
 //////////////////////////////////////
 return (
 <>

 <Header></Header>
 <div className='vh-100'>
 <div className='EditForm'>
 {

 data ?

 <>
 <form className='Form'>
 <div class="form-group">
 <label for="exampleInputEmail1">Email </label>
 <input type="email" class="form-control" id="exampleInputEmail1" ref={put_email} value={email} onChange={(e) => setEmail(e.target.value)}
 placeholder="enter email" ></input>
 </div>


 {/* <div class="form-group">
 <label for="exampleInputEmail1">Staff Id</label>
<input type="text" class="form-control" id="exampleInputEmail1" ref={put_staffId} value={staffId} onChange={(e) => setStaffId(e.target.value)} placeholder="Enter Staff Id"></input>
 </div> */}

 {/* <div class="form-group">
 <label for="exampleInputPassword1">Staff Name</label>
 <input type="text" class="form-control" id="exampleInputEmail1" ref={put_staffName} value={staffName} onChange={(e) => setStaffName(e.target.value)} placeholder="Enter Name"></input>
 </div> */}

 <div class="form-group">
 <label for="exampleInputEmail1">Availability</label>
 <input type="text" class="form-control" id="exampleInputEmail1" ref={put_availability} value={availability} onChange={(e) => setAvailability(e.target.value)} placeholder="Enter Availability"></input>
 </div>

 {/* <div class="form-group">
 <label for="exampleInputEmail1">Working Status</label>
 <input type="text" class="form-control" id="exampleInputEmail1" ref={put_workingStatus} value={workingStatus} onChange={(e) => setWorkingStatus(e.target.value)} placeholder="Enter Working Status"></input>
 </div> */}

 {/* <div class="form-group">
<label for="exampleInputEmail1">Contact Number</label>
 <input type="text" class="form-control" id="exampleInputEmail1" ref={put_contactNo} value={contactNo} onChange={(e) => setContactNo(e.target.value)} placeholder="Enter Contact Number"></input>
 </div> */}

 <div class="form-group">
 <label for="exampleInputEmail1">Gate Number</label>
 <input type="text" class="form-control" id="exampleInputEmail1" ref={put_gateNo} value={gateNo} onChange={(e) => setGateNo(e.target.value)} placeholder="Enter Gate Number"></input>
 </div>

 <div class="form-group">
 <label for="exampleInputEmail1">PNR Number</label>
 <input type="text" class="form-control" id="exampleInputEmail1" ref={put_pnrNo} value={pnrNo} onChange={(e) => setPnrNo(e.target.value)} placeholder="Enter PNR Number"></input>
 </div>

 <div className='subBtn'>
 <Link to={'/StaffAvailability'}><button type="submit" class="btn btn-primary" onClick={putData}>Edit</button></Link>
 </div>

 </form>
 </>
 :

 <>
 Loading.....

 </>
 }
 </div>

 </div>

 {/* <Footer></Footer> */}

 </>

 )

}
export default UpdateStaff



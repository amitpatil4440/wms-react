import React, { Component } from 'react'
import axios from 'axios';
import '../Supervisor/ViewSSRRequests.css';
import Header from '../Components/Header'
import { Link } from 'react-router-dom';
export default class ViewSSRRequests extends Component {
  constructor(props) {
    super(props)

    this.state = {
      
      pnrNo:'',
      Check: [],
      Policies:[]
     
    }
    // this.SearchByPNR=this.SearchByPNR.bind(this);
    // this.handleChange = this.handleChange.bind(this);
  }


  SearchByPNR = () => {
    console.log('hello')
    let pnrNo = this.state.pnrNo;

    let url = "http://localhost:53678/api/Passenger/CheckByPNR?PNRNo=" + pnrNo;
    axios.get(url).then(resp => {
      //  alert(resp.data);
console.log(resp.data);
      this.setState({

        Policies:resp.data

      });
    }).catch(error => {
      console.warn(error);
    })
  }

  handleChange=(object)=> {
   this.setState(object);
  }
  render() {
    // const {Requests} = this.state;

    const { Policies } =this.state;
    return (
      <>
      
        <Header></Header>

        <div>
          <label style={{ color: 'black', fontSize: 'large' }}><strong>Enter the PNR Number for Passenger Details</strong></label><br></br>
          <input style={{ margin: '10px', borderRadius: '5px' }} type="text" name="pnrNo" onChange={(e) => this.handleChange({ pnrNo: e.target.value })}></input><br></br>
          <button type="button" onClick={this.SearchByPNR}>Search</button>
          {/* <h2>POLICIES</h2> */}
          <div class="table-wrapper">
            <table class="fl-table">
              <thead>
                <tr>
                  <th>Passenger Id</th>
                  <th>Passenger Name</th>
                  <th>PNR Number</th>
                  {/* <th>Gate Number</th> */}
                  <th>Contact Number</th>
                  <th>Start Date</th>
                  <th>End Date</th>
                  <th>Departure</th>
                  <th>Arrival</th>
                  <th>Seat Number</th>
                  <th>Flight Class</th>
                  <th>Email</th>

                  
                </tr>
              </thead>
              <tbody>

              <tr>  <td>{Policies.pId}</td>
                    <td>{Policies.pName}</td>
                    <td>{Policies.pnrNo}</td>
                    {/* <td>{Policies.gateNo}</td> */}
                    <td>{Policies.contactNo}</td>
                    <td>{Policies.startDate}</td>
                    <td>{Policies.endDate}</td>
                    <td>{Policies.departure}</td>
                    <td>{Policies.arrival}</td>
                    <td>{Policies.seatNo}</td>
                    <td>{Policies.flightClass}</td>
                    <td>{Policies.email}</td>

                  </tr>
              </tbody>
            </table>
          </div>
        </div>
        <Link to={"/StaffAvailability"} class="hero-btn">Next Page</Link>
      </>
    )
  }
}
